require('dotenv').config();
const express = require('express');
const app = express();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
app.use(express.static('.'));
app.use(express.json());

app.post('/pay', async (req, res) => {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: 1000,
      currency: 'usd',
      payment_method: req.body.paymentMethod,
      confirm: true
    });
    res.send({ message: '✅ Payment Successful (Test Mode)' });
  } catch (error) {
    res.status(400).send({ message: error.message });
  }
});

app.listen(4242, () => console.log('Server running on http://localhost:4242'));
